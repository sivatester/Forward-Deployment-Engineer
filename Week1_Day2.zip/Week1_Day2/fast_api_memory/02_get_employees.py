from fastapi import FastAPI # fastapi is a library that allows you to create APIs in Python
app = FastAPI() # FastAPI() creates an instance of the FastAPI class, which is the main entry point for our API application

employees = [
    {"id": 1,  "name": "John Doe", "position": "Software Engineer", "salary": 80000},
    {"id": 2, "name": "Jane Smith", "position": "Data Scientist", "salary": 90000},
    {"id": 3, "name": "Bob Johnson", "position": "Product Manager", "salary": 95000},
    {"id": 4, "name": "Alice Brown", "position": "UX Designer", "salary": 85000},
]

@app.get("/employees") # @app.get() is a decorator that tells FastAPI that the function below is a GET endpoint
def get_employees(): # This function will be called when a GET request is made to the /employees endpoint
    return {"employees": employees}

@app.get("/employees/{employee_id}") # This endpoint will return a specific employee based on the employee_id provided in the URL
def get_employee(employee_id: int): # The employee_id parameter is of type int, which
    for employee in employees:
        if employee["id"] == employee_id:
            return {"employee": employee}
    return {"error": "Employee not found"}