from fastapi import FastAPI
from data_store import invoices
from models import Invoice

app = FastAPI()

@app.get("/invoices") # GET endpoint: lets you VIEW all invoices in the browser
def get_invoices():
    return {"invoices": invoices}

@app.post("/invoices") #This line defines a POST endpoint at the path "/invoices". When a client sends a POST request to this endpoint, the create_invoice function will be called to handle the request and create a new invoice.
def create_invoice(invoice: Invoice):
    new_invoice = invoice.model_dump()  #model_dump() is used to convert the Pydantic model instance into a dictionary. This allows us to easily manipulate the data and add additional fields, such as the invoice ID, before storing it in our in-memory list of invoices.
    invoice_id = len(invoices) + 1 # This line calculates the next invoice ID by taking the current length of the invoices list and adding 1. This ensures that each new invoice gets a unique ID based on the number of existing invoices.
    new_invoice["id"] = invoice_id # This line adds the calculated invoice ID to the new_invoice dictionary. By assigning the value of invoice_id to the "id" key in new_invoice, we ensure that each invoice has a unique identifier when it is stored in the invoices list.
    invoices.append(new_invoice) # This line appends the new_invoice dictionary to the invoices list. By adding the new invoice to the in-memory data store, we can keep track of all created invoices and retrieve them later if needed.
    return {"message": "Invoice created successfully", "invoice": new_invoice}
 