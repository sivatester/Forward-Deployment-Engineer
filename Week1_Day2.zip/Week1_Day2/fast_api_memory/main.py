import json
from pathlib import Path

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
DATA_FILE = Path(__file__).parent / "data" / "invoices.json" # always looks next to this file, whatever folder you run from
app = FastAPI()

class Invoice(BaseModel):
    invoice_id: str
    vendor: str
    amount: float
    status: str

with open(DATA_FILE, "r") as f:
    invoices = json.load(f)

@app.get("/") # home page, so http://127.0.0.1:8000/ no longer gives 404
def home():
    return {"message": "Invoice API is running", "try": ["/invoices", "/docs"]}

@app.get("/invoices")
def get_invoices():
    return invoices

@app.post("/invoices")
def create_invoice(invoice: Invoice):
    for existing_invoice in invoices:
        if existing_invoice["invoice_id"] == invoice.invoice_id:
            raise HTTPException(status_code=400, detail="Invoice ID already exists")
    invoices.append(invoice.model_dump()) # model_dump() is the new name for .dict() in Pydantic v2
    with open(DATA_FILE, "w") as f:
        json.dump(invoices, f, indent=4)
    return invoice
