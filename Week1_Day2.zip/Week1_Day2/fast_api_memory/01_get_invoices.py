from fastapi import FastAPI # fastapi is a library that allows you to create APIs in Python
app = FastAPI() # FastAPI() creates an instance of the FastAPI class, which is the main entry point for our API application

invoices = [
    {"id": 1, "amount": 100.0, "customer": "John Doe", "status": "paid"},
    {"id": 2, "amount": 200.0, "customer": "Jane Smith", "status": "pending"},
    {"id": 3, "amount": 300.0, "customer": "Bob Johnson", "status": "overdue"},
    {"id": 4, "amount": 400.0, "customer": "Alice Brown", "status": "paid"},
]

@app.get("/invoices") # @app.get() is a decorator that tells FastAPI that the function below is a GET endpoint
def get_invoices(): # This function will be called when a GET request is made to the /invoices endpoint
    return {"invoices": invoices}

@app.get("/invoices/{invoice_id}") # This endpoint will return a specific invoice based on the invoice_id provided in the URL
def get_invoice(invoice_id: int): # The invoice_id parameter is of type int, which
    for invoice in invoices:
        if invoice["id"] == invoice_id:
            return {"invoice": invoice}
    return {"error": "Invoice not found"}