
# write a python code to print username, email, and company name of all users from the API endpoint "https://jsonplaceholder.typicode.com/users"

import requests # requests is a library that allows you to send HTTP requests in Python

URL = "https://jsonplaceholder.typicode.com/users"  
# This is the URL of the API endpoint we want to send a GET request to

response = requests.get(URL, timeout=10)
# The requests.get() function sends a GET request to the specified URL and returns a Response object that contains the server's response to the request.
# timeout=10 means: give up if the server doesn't answer within 10 seconds

response.raise_for_status()
# Stops the program with a clear error if the request failed (e.g. 404 or 500)

users = response.json()
# The response.json() method parses the JSON response from the server.
# Here it returns a LIST of user dictionaries (one dictionary per user)
# response.json() takes the text the API sent back and converts it into Python data. For this API, the result is a list of 10 dictionaries

print(f"Status code: {response.status_code}")
print(f"Total users: {len(users)}\n")
# length of users - 10

for user in users:
    username = user["username"]
    email = user["email"]
    company_name = user["company"]["name"]
    # "company" is a dictionary inside the user dictionary, so we go one level deeper to get "name"
    phone_parts = user["phone"].split("x") # split the phone number by 'x' -> ['1-770-736-8031 ', '56442']
    phone = phone_parts[0].strip()         # first part is the number; strip() removes the extra space
    if len(phone_parts) > 1:               # 2 parts means there is an extension
        phone_ext = phone_parts[1]         # second part is the extension
    else:                                  # only 1 part means no extension
        phone_ext = ""                     # empty text, so phone_ext is ALWAYS defined
    print(f"Username: {username} | Email: {email} | Company: {company_name} | Phone: {phone} | Ext: {phone_ext}")
