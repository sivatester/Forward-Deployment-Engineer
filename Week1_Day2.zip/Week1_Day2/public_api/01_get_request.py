import requests # requests is a library that allows you to send HTTP requests in Python

URL = "https://jsonplaceholder.typicode.com/posts/1"  
# This is the URL of the API endpoint we want to send a GET request to

response = requests.get(URL)
# The requests.get() function sends a GET request to the specified URL and returns a Response object that contains the server's response to the request.

data = response.json()
# The response.json() method parses the JSON response from the server and returns it as a Python dictionary.

print(response.status_code)
#print(response.json())

print(data["title"])
print(data["body"])
print(response.json())
